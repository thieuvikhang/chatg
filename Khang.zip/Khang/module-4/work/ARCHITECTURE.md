# Pipeline architecture

```mermaid
flowchart LR
  P[pr-planner<br/>Haiku 5.5, tools: read] --> R1[file-reviewer #1<br/>Sonnet 5.5, tools: read, search]
  P --> R2[file-reviewer #2]
  P --> Rn[file-reviewer #N]
  R1 --> A[review-aggregator<br/>Sonnet 5.5, tools: none]
  R2 --> A
  Rn --> A
  A --> V[review-verifier<br/>Sonnet 5.5, tools: read, search]
  V --> D{verdict}
```

| Agent | Role | Model | Tools | Input schema | Output schema |
|---|---|---|---|---|---|
| pr-planner | list changed files | Haiku 5.5 | read | `planner_task` | `plan` |
| file-reviewer (xN, parallel) | review one file | Sonnet 5.5 | read, search | `reviewer_task` | `ReviewResult` |
| review-aggregator | merge reviews | Sonnet 5.5 | none | `aggregator_task` | `ReviewResult` |
| review-verifier | check review against diff | Sonnet 5.5 | read, search | `verifier_task` | `verdict` |

Every handoff is validated in `pipeline.py`. On failure the producer gets one repair attempt, then the run exits with code 3.

Note: the verifier uses the same model family as the reviewer, so its independence is weaker than the handout intends.
