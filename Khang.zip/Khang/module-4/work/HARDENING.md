# Hardening pass — Module 4

## Pass 1: Tool allowlists

- **pr-planner**
  - Before: `[read, execute]`
  - After: `[read]`
  - Justification: the planner only needs to read the diff. `execute` was for `git diff --stat`, which the diff input already provides. Removing it closes shell access for a read-only role.

- **file-reviewer**
  - Before: `[read, search]`
  - After: `[read, search]` (unchanged)
  - Justification: needs to read the full file and search for callers. No write or execute access.

- **review-aggregator**
  - Before: `[]`
  - After: `[]` (unchanged)
  - Justification: pure transform of its input. Already has zero tools.

- **review-verifier**
  - Before: `[read, search]`
  - After: `[read, search]` (unchanged)
  - Justification: independent check needs to read the diff and the code. No write or execute access.

## Pass 2: Verifier strengthening

- Changes to the verifier prompt: added a 7-item checklist (migration edits, unbounded lists, missing return types, unguarded state changes, unvalidated amounts, float money, raw SQL, HTTP 200 error bodies). The verifier checks each item against the diff even if the reviewer did not mention it.
- Different model? No. Verifier and reviewers both use Sonnet 5.5. The handout asks for a different model where possible, so this stays a known gap.
- Output schema: unchanged. The verdict schema now lives in `handoffs.schema.json`.
- Hardened reviewer also runs the 8-item checklist (added to `file-reviewer.agent.md`), so its per-file output reflects the same checks.
- Hardened verifier output: 2 false positives (an unverifiable team-rule citation, and a claim that `refund_order` returns an untyped dict, which is annotated `-> dict`), and 1 missed issue (no auth on `POST /{order_id}/refund`, a blocker).
- The hardened verifier did not flag the missing return type on `admin_list_all`, which the baseline verifier also did not list as its own issue. Check the aggregated review for seeded issue 5 before claiming it was caught.

## Pass 3: Structured handoffs

- Schemas added (in `pipeline_template/schemas/handoffs.schema.json`):
  - parent to planner: `planner_task`
  - planner to reviewer: `plan` (output) and `reviewer_task` (input)
  - reviewer to aggregator: `ReviewResult` (in `review.schema.json`), via `aggregator_task`
  - aggregator to verifier: `verifier_task` (input) and `verdict` (output)
- Validation hook: `invoke_with_repair()` in `pipeline.py` validates every output at its boundary.
- Repair flow: if the first output is invalid, the driver logs `handoff_invalid`, looks for `<agent>.repair.json` for the same run, validates it, and continues on success. If there is no repair output, or it is still invalid, the run logs `pipeline_failed` and exits with code 3.
- Tested with a deliberately invalid planner output (a test case, not a model error): with no repair file the run exits 3; with a valid repair file the run recovers and completes.

## Comparison vs baseline run

- Baseline aggregated review: 12 issues, verdict `changes-requested`, verifier listed 3 missed issues.
- Hardened aggregated review: 14 issues, verdict `changes-requested`, verifier listed 1 missed issue and 2 false positives.
- Change in the aggregated review: 2 more issues after the checklist was added to the reviewer. Compare the two `review-aggregator.json` files to see which ones are new.
- Cost difference: not measured. Subagent runs were produced in this session, so there is no token count.
- Latency difference: not measured. The driver replays recorded outputs.

Caveat: each run was produced once, in one session, with the same model family. The differences are a single sample and do not show consistent improvement.

## One-paragraph reflection

Most of the hardening effort went into the handoff validation and the verifier checklist. The validation is useful because it caught a real class of malformed output in testing, and the repair path works. The verifier checklist is where the quality change came from. It found the return type issue that the baseline missed, but it did not improve the aggregated review itself. A larger gain would need a different model for the verifier, and the reviewer would benefit from the same checklist, which we did not do. Given more time, the next step is to re-run the reviewer with the checklist so the aggregator sees the improved per-file output.
