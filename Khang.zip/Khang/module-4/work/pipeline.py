"""Pipeline driver for the Module 4 lab, hardened version.

Stages: pr-planner -> file-reviewer (parallel) -> review-aggregator -> review-verifier.
Every handoff is validated against schemas. On a validation failure the driver
asks the producer for one repaired output, then fails if it is still invalid.

Outputs are read from runs/<run_name>/<agent>[__<key>].json. Repair outputs are
read from runs/<run_name>/<agent>[__<key>].repair.json.

Usage:
  python3 pipeline.py <diff_path> <run_name>
"""
from __future__ import annotations

import asyncio
import json
import sys
import time
from pathlib import Path

from jsonschema import Draft7Validator

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"
SCHEMAS = json.loads((HERE / "pipeline_template" / "schemas" / "handoffs.schema.json").read_text())
REVIEW_SCHEMA = json.loads((HERE / "pipeline_template" / "schemas" / "review.schema.json").read_text())


class ValidationFailed(Exception):
    pass


def log(stage: str, **fields) -> None:
    print(json.dumps({"stage": stage, "ts": time.time(), **fields}))


def check(obj: dict, schema: dict, label: str) -> None:
    errors = sorted(Draft7Validator(schema).iter_errors(obj), key=lambda e: list(e.path))
    if errors:
        msgs = "; ".join(f"{'.'.join(map(str, e.absolute_path)) or '<root>'}: {e.message}" for e in errors)
        raise ValidationFailed(f"{label}: {msgs}")


LIVE = json.loads((HERE / "config.json").read_text(encoding="utf-8-sig")).get("live", False)
AGENT_NAME = {"pr-planner": "pr-planner", "file-reviewer": "file-reviewer",
              "review-aggregator": "review-aggregator", "review-verifier": "review-verifier"}


def invoke_with_repair(run_dir: Path, name: str, task: dict, schema: dict, key: str = "") -> dict:
    """Get the output (live API or recorded file), validate it, retry once from the repair output, then fail."""
    base = f"{name}__{key}" if key else name
    task_path = run_dir / f"{base}.task.json"
    task_path.write_text(json.dumps(task, indent=2), encoding="utf-8")

    if LIVE:
        from subagent_api import invoke_subagent
        output = invoke_subagent(AGENT_NAME[name], task, schema)
        check(output, schema, f"{name} live output")
        (run_dir / f"{base}.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
        log("handoff_ok", agent=name, key=key, attempt=1, source="live")
        return output

    first = run_dir / f"{base}.json"
    if not first.exists():
        raise FileNotFoundError(f"no recorded output for {name} at {first}")
    output = json.loads(first.read_text(encoding="utf-8-sig"))
    first_error = ""
    try:
        check(output, schema, f"{name} output")
        log("handoff_ok", agent=name, key=key, attempt=1)
        return output
    except ValidationFailed as err:
        first_error = str(err)
        log("handoff_invalid", agent=name, key=key, attempt=1, error=first_error)

    repair = run_dir / f"{base}.repair.json"
    if not repair.exists():
        raise ValidationFailed(f"{name} invalid and no repair output recorded: {first_error}")
    repaired = json.loads(repair.read_text(encoding="utf-8-sig"))
    check(repaired, schema, f"{name} repaired output")
    log("handoff_repaired", agent=name, key=key, attempt=2)
    return repaired


async def run_reviewers_parallel(run_dir: Path, plan: dict, diff_text: str) -> list[dict]:
    async def _one(file_entry: dict) -> dict:
        key = file_entry["path"].replace("/", "_").replace(".", "_")
        task = {"file": file_entry["path"], "diff": diff_text}
        return await asyncio.to_thread(
            invoke_with_repair, run_dir, "file-reviewer", task, REVIEW_SCHEMA, key)
    return await asyncio.gather(*[_one(f) for f in plan["files"]])


async def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("usage: pipeline.py <diff_path> <run_name>", file=sys.stderr)
        return 2
    diff_path = Path(argv[1])
    run_dir = RUNS / argv[2]
    run_dir.mkdir(parents=True, exist_ok=True)
    diff_text = diff_path.read_text(encoding="utf-8-sig")

    log("planner_start")
    plan = invoke_with_repair(run_dir, "pr-planner", {"diff": diff_text},
                              SCHEMAS["plan"])
    log("planner_done", files=len(plan["files"]))

    log("reviewers_start")
    per_file = await run_reviewers_parallel(run_dir, plan, diff_text)
    log("reviewers_done", count=len(per_file))

    log("aggregator_start")
    combined = invoke_with_repair(run_dir, "review-aggregator", {"reviews": per_file},
                                  REVIEW_SCHEMA)
    log("aggregator_done", issues=len(combined["issues"]))

    log("verifier_start")
    verdict = invoke_with_repair(run_dir, "review-verifier",
                                 {"diff": diff_text, "review": combined},
                                 SCHEMAS["verdict"])
    log("verifier_done", verdict=verdict["verdict"])

    (run_dir / "result.json").write_text(json.dumps(
        {"plan": plan, "combined_review": combined, "verdict": verdict}, indent=2),
        encoding="utf-8")
    return 0


if __name__ == "__main__":
    try:
        code = asyncio.run(main(sys.argv))
    except ValidationFailed as err:
        log("pipeline_failed", error=str(err))
        code = 3
    raise SystemExit(code)
