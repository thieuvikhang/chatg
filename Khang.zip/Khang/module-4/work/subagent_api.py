"""Live subagent invocation through the Anthropic Messages API.

The system prompt is the body of work/agents/<name>.agent.md. The task is sent as JSON.
Output is parsed as JSON and validated against an optional schema. On failure the
model gets one correction turn per retry before the call raises.

Requires: pip install anthropic pyyaml jsonschema
Env: ANTHROPIC_API_KEY. Model IDs are read from config.json.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

import anthropic
import yaml
from jsonschema import Draft7Validator

HERE = Path(__file__).resolve().parent
AGENTS = HERE / "agents"

CONFIG_PATH = HERE / "config.json"


def load_agent(name: str) -> tuple[dict, str]:
    text = (AGENTS / f"{name}.agent.md").read_text(encoding="utf-8-sig")
    _, fm, body = text.split("---", 2)
    return yaml.safe_load(fm), body.strip()


def load_config() -> dict:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))


def resolve_model(display_name: str) -> str:
    model_id = load_config().get("models", {}).get(display_name, "")
    if not model_id or model_id.startswith("<"):
        raise RuntimeError(f"set models[{display_name!r}] in {CONFIG_PATH.name} to the API model ID")
    return model_id


def _strip_fences(text: str) -> str:
    match = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    return match.group(1).strip() if match else text.strip()


def invoke_subagent(name: str, task: dict, schema: dict | None = None,
                    max_attempts: int = 2) -> dict:
    meta, system = load_agent(name)
    model = resolve_model(meta["model"])
    client = anthropic.Anthropic()
    validator = Draft7Validator(schema) if schema else None

    messages = [{"role": "user", "content": json.dumps(task, ensure_ascii=False)}]
    error = ""
    for _ in range(max_attempts):
        resp = client.messages.create(model=model, max_tokens=4096,
                                      system=system, messages=messages)
        text = "".join(block.text for block in resp.content if block.type == "text")
        try:
            obj = json.loads(_strip_fences(text))
        except json.JSONDecodeError as err:
            error = f"not valid JSON: {err}"
        else:
            errors = sorted(validator.iter_errors(obj), key=lambda e: list(e.path)) if validator else []
            if not errors:
                return obj
            error = "; ".join(f"{'.'.join(map(str, e.absolute_path)) or '<root>'}: {e.message}"
                              for e in errors)
        messages.append({"role": "assistant", "content": text})
        messages.append({"role": "user", "content":
                         f"Your output failed validation: {error}. Return the corrected JSON only."})

    raise ValueError(f"{name} failed after {max_attempts} attempts: {error}")
