# CLAUDE.md — payments-api

## Project overview

- FastAPI service for customer orders and authentication. Single process, version 0.3.1.
- Two modules under `app/`: `auth/` (login, token issuance) and `orders/` (order CRUD).
- Shared public types live in `app/types.py`. Shared DB engine and session helpers live in `app/db.py`.
- Production database is Postgres 15. Tests use Postgres too, never SQLite.

## Build & test

- Install dependencies: `make setup` (runs `uv sync`).
- Lint: `make lint` (ruff). Type check: `make type` (mypy, strict).
- Run all tests: `make test`. Integration tests only: `make test-integration`.
- Run the dev server: `make run` (uvicorn on port 8000).
- Run lint, type check, and tests before reporting a task as done.
- Python >= 3.11. Line length 100 (ruff).

## Conventions

- Start every Python file with `from __future__ import annotations`.
- Use Pydantic v2 models for all request and response bodies.
- Put any type that crosses a module boundary in `app/types.py`. Keep internal types private to their module.
- Route handlers in `app/orders/routes.py` and `app/auth/handlers.py` must not contain business logic. Delegate to a function in the same module or a sibling.
- Put database access for a module in its own repository file (`app/orders/repository.py`, `app/auth/queries.py`). Routes must not query ORM models directly.
- Give every new endpoint an integration test under `tests/integration/`. Follow the pattern in `test_orders.py`: arrange with `app.types` models, act with the `client` fixture, assert status first, then specific fields.
- Avoid asserting full payload equality when IDs or timestamps are present.
- Use `from app.db import Base` for ORM models.
- Read secrets from environment variables. Do not hardcode them.

## Do not

- Do not modify anything under `app/auth/` without explicit human review. This code is security-sensitive and needs sign-off from the security lead.
- Do not change JWT token TTL, signing keys, algorithm, or password verification logic.
- Do not edit `migrations/0001_initial.sql` or any existing migration. Migrations are append-only. Add schema changes as a new file `migrations/000N_<name>.sql` with the next number.
- Do not change `app/db.py` to use SQLite or any non-Postgres database.
- Do not use SQLite in tests, including as a "faster" mode.
- Do not add dependencies to `pyproject.toml` without saying so in the summary.
- Do not commit secrets, connection strings with real credentials, or `.env` files.

## Glossary

- **Order**: a customer's purchase intent. Created in `pending`, then moves to `paid`, then `shipped`. Can move to `cancelled` from any non-terminal state.
- **Order item**: one line on an order, with `sku`, `quantity`, and `unit_price`.
- **Token**: a JWT issued at login. TTL 24 hours. Signed with HS256. Secret comes from the `JWT_SECRET` environment variable.
- **Repository**: the module-internal persistence layer (`repository.py` or `queries.py`).

## Escalation

- Auth changes, token or crypto changes, or anything touching password handling: stop and ask a human. Owner is the security lead.
- Migration changes to existing files: stop and ask. Create a new migration file instead.
- Database engine change: stop and ask. Do not propose it as a fix.
- Unclear whether a change crosses a module boundary: ask, and default to placing the type in `app/types.py`.

## Examples

Adding an endpoint follows this order:

1. Define request and response models in `app/types.py`.
2. Add the route in the relevant `routes.py`, with delegation to a function in the module.
3. Add persistence in the module's repository file if needed.
4. Add an integration test in `tests/integration/test_<module>.py`.

Example integration test shape (from `tests/integration/test_orders.py`):

```python
@pytest.mark.asyncio
async def test_create_order_rejects_empty_items(client: AsyncClient) -> None:
    resp = await client.post("/orders", json={"user_id": 42, "items": []})
    assert resp.status_code == 400
```

## Imports and pointers

- Architecture notes: `docs/architecture.md`.
- Build commands: `Makefile`. Tool config: `pyproject.toml`.
- Schema: `migrations/0001_initial.sql`.
- Product overview: `README.md`.
