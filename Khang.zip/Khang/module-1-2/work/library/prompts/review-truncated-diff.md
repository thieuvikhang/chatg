---
name: review-truncated-diff
version: 1.0.0
model: claude-sonnet-4-5
input_kind: unified_diff
output_kind: error_json
---

Review the diff below against the team checklist: no business logic in route handlers, no SQL built from strings, and an integration test for each new endpoint.

Error handling rules:
- If the diff is incomplete (for example, a hunk header says more lines than are present, or the diff ends mid-statement), do not review it.
- Output exactly one JSON object: {"error": "truncated_diff", "reason": "<short reason>"}.
- If the diff is complete, output a review in this form: {"issues": [...], "summary": "..."} with the same fields as the review-diff prompt.
- No prose. No markdown fences.

Diff:

<input>
{INPUT}
</input>
