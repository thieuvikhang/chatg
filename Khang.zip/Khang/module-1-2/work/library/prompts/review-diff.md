---
name: review-diff
version: 1.0.0
model: claude-sonnet-4-5
input_kind: unified_diff
output_kind: review_json
---

You are reviewing a unified diff for payments-api (FastAPI + SQLAlchemy, Postgres).

Team rules to check against:
- Route handlers must not contain business logic or direct DB queries. Delegate to the module's repository.
- Changes under app/auth/ need human security review. Report them as blocker.
- Every new endpoint needs an integration test under tests/integration/.
- Never build SQL from strings. Use parameterized queries.

Output rules:
- Output one JSON object matching the schema below. No prose. No markdown fences.
- severity is one of: blocker, major, minor, nit.
- category is one of: correctness, security, performance, style, testing.
- file is the path from the diff. line is a positive integer in the new file.
- message is at most 280 characters.
- suggestion is a string or null.
- If there are no issues, return "issues": [].

Schema:
{"issues": [{"severity": "...", "category": "...", "file": "...", "line": 1, "message": "...", "suggestion": "... or null"}], "summary": "..."}

Diff:

<input>
{INPUT}
</input>
