---
name: review-repair
version: 1.0.0
model: claude-sonnet-4-5
input_kind: json_plus_validator_error
output_kind: review_json
---

A previous code-review response failed JSON schema validation. The input below has the ORIGINAL response and the VALIDATOR_ERROR.

Fix only the reported errors. Keep every other issue unchanged.

Output rules:
- Output the full corrected JSON object with keys "issues" and "summary".
- severity is one of: blocker, major, minor, nit.
- category is one of: correctness, security, performance, style, testing.
- No prose. No markdown fences.

Input:

<input>
{INPUT}
</input>
