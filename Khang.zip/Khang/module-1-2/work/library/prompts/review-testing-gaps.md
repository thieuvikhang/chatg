---
name: review-testing-gaps
version: 1.0.0
model: claude-sonnet-4-5
input_kind: unified_diff
output_kind: markdown_list
---

List missing or weak tests for the changes in the diff below.

Check for:
- New endpoints without an integration test under tests/integration/.
- Tests that check only the status code when the endpoint changes data.
- Missing negative cases (invalid input, unknown IDs).

Output rules:
- One item per gap, in this form: - <test name or file>: <gap>
- No text outside the list.
- If nothing is missing, output exactly: NO_TEST_GAPS

Diff:

<input>
{INPUT}
</input>
