---
name: review-empty-diff
version: 1.0.0
model: claude-sonnet-4-5
input_kind: unified_diff
output_kind: text_token
---

Check the diff below.

- If it is empty or contains only whitespace, output exactly: NO_CHANGES
- Otherwise, output exactly: REVIEW_REQUIRED

Output only one of these two tokens. No other text.

Diff:

<input>
{INPUT}
</input>
