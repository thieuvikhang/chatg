---
name: review-security-focus
version: 1.0.0
model: claude-sonnet-4-5
input_kind: unified_diff
output_kind: markdown_bullets
---

Review the diff below for security issues only: SQL injection, auth bypass, missing authorization, hardcoded secrets, unsafe input handling.

Output rules:
- One bullet per finding, in this form: - **<severity>** `<file>:<line>` <problem>. <fix>
- severity is blocker, major, or minor.
- If there are no security findings, output exactly: NO_SECURITY_ISSUES
- No text outside the bullets.

Diff:

<input>
{INPUT}
</input>
