# Regression log — Step 3

## CI workflow

`.github/workflows/eval.yml` runs `python3 harness/run_eval.py --strict` on pull requests that touch `prompts/`, `goldens/`, or `harness/`.

## Baseline

Command: `python3 harness/run_eval.py --strict`. Exit code: 0, 6/6 passed.

## Deliberate regression

Changed the golden fixture `goldens/review_full_sql_injection.fixture.txt` to a review that misses the SQL injection in the delete endpoint. This simulates a prompt change that stops the model from flagging security issues.

Fixture after regression:

```json
{"issues": [], "summary": "Looks fine."}
```

## Captured failing run

Command: `python3 harness/run_eval.py --strict`

```
[PASS] empty_diff                     -> ok
[PASS] review_clean_diff              -> ok
[FAIL] review_full_sql_injection      -> missing substring: '"category": "security"'
[PASS] security_focus_sql             -> ok
[PASS] testing_gaps_delete            -> ok
[PASS] truncated_diff_error           -> ok

5/6 passed
```

Exit code: 1. CI would block the merge.

Golden that caught it: `review_full_sql_injection`. Its `expected_substrings` requires a security-category issue.

## Restore

Fixture restored from the original. Command output:

```
6/6 passed
```

Exit code: 0.

## Note

This is a simulated regression. The offline harness returns fixtures and never calls the prompt, so the regression was introduced in the fixture rather than the prompt text. A live agent run would change the prompt and produce the same kind of drift.
