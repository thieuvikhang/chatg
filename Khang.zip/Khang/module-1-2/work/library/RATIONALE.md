# Rationale — Code review

> 🎯 **File này để làm gì?** Chỗ để bạn nói ra *vì sao mình chọn như vậy* — sao lại 5 prompt này, golden set có gì trong đó, ngưỡng pass để bao nhiêu. Cứ điền từng mục bằng câu trả lời của chính bạn.  
> 💡 **Sao phải viết ra, làm xong là được rồi mà?** Vì ngoài đời, người tiếp quản sau bạn — hoặc chính bạn ba tháng nữa quay lại — cần hiểu *tại sao* bộ prompt được làm thế này, chứ không chỉ *nó là cái gì*. Một quyết định không ghi lại là một quyết định sẽ có người lặp lại sai. Cái đoạn reflection ở cuối ("có thêm buổi nữa bạn làm khác gì") cũng tính điểm đấy — nó cho thấy bạn *học* được gì, chứ không chỉ *làm* được gì.  

## Task family

Code review (against a checklist). Chọn family này vì team review diff lặp lại và có checklist rõ: route không chứa logic, không SQL nối chuỗi, có integration test.

## The five prompts

1. `review-diff` — happy path: review tổng quát theo checklist, trả JSON theo schema (đây là prompt schema-constrained, có validator).
2. `review-empty-diff` — edge case: diff rỗng trả `NO_CHANGES`, còn lại `REVIEW_REQUIRED`.
3. `review-truncated-diff` — error case: diff bị cắt giữa chừng thì trả lỗi `truncated_diff` thay vì bịa review.
4. `review-security-focus` — trục tự chọn 1: chỉ tìm lỗi bảo mật, trả bullet hoặc `NO_SECURITY_ISSUES`.
5. `review-testing-gaps` — trục tự chọn 2: liệt kê test còn thiếu, trả list hoặc `NO_TEST_GAPS`.

## The golden set

- 6 cặp tổng cộng (cover đủ 5 prompt).
- Source: synthetic. Diff và response mẫu do mình viết tay, không lấy từ việc thật của team.
- Một regression trông như thế nào: fixture của `review_full_sql_injection` đổi thành review không có issue bảo mật. Harness báo `[FAIL]` và thoát với mã 1 (đã ghi trong REGRESSION_LOG.md).

## What the harness measures

- Kiểm tra substring có mặt trong output (`expected_substrings`).
- Không dùng `expected_count_at_least`.
- Pass threshold: 100% goldens khi chạy `--strict` (kết quả hiện tại 6/6). Mục tiêu ban đầu của lab là trên 80%.

## What's not yet good enough

- Harness đang chạy offline bằng fixture viết tay, nên nó kiểm tra harness chứ chưa kiểm tra model thật.
- Chưa chạy agent thật cho prompt nào. Schema và repair flow mới chỉ kiểm tra qua một file run và một fixture.
- Substring check dễ qua nếu output đúng từ khoá nhưng sai nội dung.
- Kết quả Step 4 không giữ được code của từng lần chạy, và mỗi điều kiện chỉ chạy một lần.

## What I'd do next

- Nối `call_agent()` với Claude CLI hoặc API, chạy lại 6 goldens trên model thật, rồi đo pass rate thật.
- Thay substring bằng kiểm tra từng trường JSON (severity, category, file, line).

## Reflection

Nếu làm lại buổi này, mình sẽ chạy agent thật ngay từ đầu thay vì dùng fixture, để pass rate phản ánh model chứ không phản ánh chính mình viết mẫu. Mình cũng sẽ giữ lại code của từng lần chạy Step 4 bằng commit hoặc thư mục riêng, để so sánh được code chứ không chỉ báo cáo của agent. Cuối cùng, mình sẽ viết golden trước khi viết prompt để tránh điều chỉnh mẫu cho khớp với prompt.
