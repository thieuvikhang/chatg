# Verification report — Step 4

Prompt: "Add a new endpoint that returns the count of orders for a given user." run in `work/repo/` twice. Run 1 had `CLAUDE.md` and `AGENTS.md` present. Run 2 had both renamed to `.bak`. Full reports: [run_with.md](run_with.md) and [run_without.md](run_without.md).

## Caveats

- Each condition ran once, so differences may be noise.
- The `work/repo/` code from both runs was not kept. Run 1's code was overwritten when I restored the repo to starter state before run 2, and run 2's code was reverted afterward. The comparison below uses the agents' self-reports only.
- Neither run could execute lint, type check, or tests. `make`, `uv`, `ruff`, `pytest`, `mypy`, and Postgres are not available in this environment.

## Differences observed

1. **Return type name.** With files: `OrderCountResponse` (fields `user_id`, `count`). Without files: `OrderCount` (same fields). Both placed it in `app/types.py`. This matches the rule in `CLAUDE.md` and `AGENTS.md` ("Put any type that crosses a module boundary in `app/types.py`"), but the naming itself is not governed by any rule, so it is not a context-file effect.

2. **Context files read first.** With files: the agent read `CLAUDE.md` and `AGENTS.md` at the start of its plan and cited their rules (Pydantic models in `app/types.py`, no logic in routes, `repository.py` for DB access, integration test per endpoint, no edits to `app/auth/` or `migrations/`). Without files: the agent was told not to read them and did not. Both runs still followed the same structure.

3. **Test-first report wording.** With files: the agent's plan says both tests "assert status first, then fields", which matches the example pattern in `CLAUDE.md` ("assert status first, then specific fields") and the `test_orders.py` docstring. Without files: the report does not state an assertion pattern. The code was not kept, so I cannot confirm the assertion order in either run.

4. **Build command attempt.** With files: the agent first checked for `make` and `uv` and found neither. Its final summary told the user to run `make setup`, `make lint`, `make type`, and `make test`, which matches the `CLAUDE.md` build section. Without files: the agent tried `make lint; make test` directly and failed on `make` not being found. Both fell back to `py_compile` and a line-length scan.

5. **Endpoint URL and shape.** Both chose `GET /orders/count?user_id=N` with the same JSON shape. This was not changed by the context files in this run. The `GET /orders?user_id=` pattern already existed in `routes.py`, and both agents followed it.

## Traceability

| Observed behavior | Rule in context file | Effect of the file |
|---|---|---|
| Type placed in `app/types.py` (both runs) | `CLAUDE.md` Conventions; `AGENTS.md` Conventions | Not distinguishable here, since the code pattern in `app/types.py` is also clear |
| Route delegates to repository (both runs) | `CLAUDE.md` Conventions: "Route handlers ... must not contain business logic" | Not distinguishable here |
| Plan cites no-auth and no-migration rules (run 1 only) | `CLAUDE.md` Do not | Yes, this is the clearest with-file effect |
| Assertion-order wording (run 1 only) | `CLAUDE.md` Examples and Conventions | Yes, but unverified in code |

## Conclusion

The context files had a small visible effect on the agent's stated plan and on its explicit citation of rules. They did not change the endpoint design, and the code itself could not be compared. The task is simple and the surrounding code already shows the pattern, so the baseline agent also followed it. A stronger test would use a task that the codebase does not already demonstrate, and would run each condition several times while keeping the generated code.
