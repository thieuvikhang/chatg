# AGENTS.md — migration workflow (payments-api)

## Scope

- Target repo: `labs/module-1-2/work/repo` (payments-api, FastAPI + SQLAlchemy, Postgres 15).
- This workflow only creates new migration files. It does not apply migrations and does not change application code.
- Migration folder: `<target>/migrations/`. Files are named `000N_<snake_name>.sql`.

## Migration rules

- Migrations are append-only. Never edit or delete `0001_initial.sql` or any existing migration.
- Use Postgres syntax. The schema uses `JSONB` and `TIMESTAMPTZ`.
- Allowed types: `TEXT`, `INTEGER`, `BIGINT`, `BOOLEAN`, `TIMESTAMPTZ`, `JSONB`, `VARCHAR(n)`, `NUMERIC(p, s)`.
- Identifiers are lowercase snake_case, at most 63 characters.
- New columns are nullable, or `NOT NULL` with a `DEFAULT`.
- Use `IF NOT EXISTS` for `CREATE INDEX`.
- One logical change per file.
- Every migration ends with a rollback block between `-- ROLLBACK BEGIN` and `-- ROLLBACK END`. Each rollback line is a comment that exactly inverts the forward statements.
- Destructive changes (`DROP`, `TRUNCATE`, `DELETE FROM`) need explicit confirmation. The generator stops and writes nothing.
- The generator rejects a column or index that already exists in the migrations folder.

## Workflow

1. Parse the request into a spec JSON using `.github/skills/generate-migration/reference/parse-request.md`.
2. Run `python .github/skills/generate-migration/scripts/migrate.py <spec.json> <target>/migrations`.
3. Invoke the `migration-verifier` agent, save its JSON to `verdict.json`, and re-run with `--verdict verdict.json`.
4. Exit codes: 0 written, 1 invalid request or schema conflict, 3 rollback or verifier rejected or missing, 4 destructive change blocked.

## Do not

- Do not modify anything under `app/auth/` in the target repo.
- Do not add dependencies to the target repo's `pyproject.toml`.
- Do not write migration files when a check fails.
