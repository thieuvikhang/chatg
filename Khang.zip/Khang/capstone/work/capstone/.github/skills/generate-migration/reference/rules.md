# Migration rules

## Naming

- File: `migrations/000N_<snake_name>.sql`. `N` is the next number, zero-padded to 4 digits.
- `add_column` files are named `add_<table>_<column>`. `create_index` files are named `create_<index_name>`.
- Numbers are ascending with no gaps. The number script checks this.

## Destructive operations (stop, never written)

- `DROP TABLE`
- `DROP COLUMN`
- `DROP SCHEMA`
- `TRUNCATE`
- `DELETE FROM` (data changes belong in a separate, reviewed data migration)

The driver prints `ERROR destructive_blocked: <statement>. Confirmation required. No migration written.` and exits 4.

## Safe defaults

- New columns: nullable, or `NOT NULL` with a `DEFAULT`.
- Indexes: `CREATE INDEX IF NOT EXISTS`.

## Rollback block

Every file ends with this block:

```
-- ROLLBACK BEGIN (manual, not executed by the deploy pipeline)
-- ALTER TABLE orders DROP COLUMN notes;
-- ROLLBACK END
```

- Each rollback line is a comment and exactly inverts the forward statements.
- `ADD COLUMN` rolls back with `DROP COLUMN` on the same table and column.
- `CREATE INDEX` rolls back with `DROP INDEX IF EXISTS` on the same name.
- The rollback block is not executed. Rollback is a manual step, reviewed by a human.

## Schema check

Before writing, the skill rebuilds the schema from every file in `migrations/`. It handles `CREATE TABLE`, `ADD COLUMN`, `RENAME COLUMN`, `DROP COLUMN`, `CREATE INDEX`, and `DROP TABLE`. A column or index that already exists is a conflict.

## Out of scope for this skill

- Editing or deleting an existing migration.
- Running migrations. Deployment applies them.
- Application code that uses the new schema.
