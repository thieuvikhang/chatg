---
name: generate-migration
version: 1.1.0
description: 'Generate one append-only SQL migration with a rollback block in migrations/ from a schema-change request such as "add a notes column to orders". Checks that the column or index does not already exist, stops for confirmation on destructive changes, and checks the rollback. Do NOT use for editing or deleting existing migrations, running migrations, application code changes, or SELECT queries.'
---

# Generate Migration

Creates one `migrations/000N_<snake_name>.sql` file per schema change. Each file has forward statements and a rollback block. Migrations are append-only.

## Steps

1. Turn the request into a spec JSON by following [the parse prompt](./reference/parse-request.md). Save it to a temporary `spec.json`.
2. Run the driver once without a verdict to get the checks: `python <skill>/scripts/migrate.py spec.json <target>/migrations`, where `<skill>` is `.github/skills/generate-migration`. It runs spec validation, the destructive gate, the next number, the schema conflict check, and the rollback check. If it exits 1, 3, or 4, stop and report the `ERROR` line. Nothing is written.
3. Invoke the `migration-verifier` agent with the spec and the rendered migration text. Save only its JSON object to `verdict.json`.
4. Run the driver again with the verdict: `python <skill>/scripts/migrate.py spec.json <target>/migrations --verdict verdict.json`.
5. Handle the final exit code:
   - 0: report the path and the statements written. Do not run the migration.
   - 1 or 3: stop and report the `ERROR` line. No file is written.
   - 4: print only the `ERROR destructive_blocked` line, then end the turn.
6. Delete the temporary `spec.json` and `verdict.json`.

## Example

Request: "Add a notes column (TEXT, nullable) to the orders table."

- Spec: `{"operation": "add_column", "table": "orders", "column": "notes", "type": "TEXT", "nullable": true}`
- Driver prints the next number `0002`, passes the checks, and the migration-verifier agent approves reversibility. The driver then writes `migrations/0002_add_orders_notes.sql`.
- File contains `ALTER TABLE orders ADD COLUMN notes TEXT;` and `-- ALTER TABLE orders DROP COLUMN notes;` inside the rollback block.

## Conventions

- Only create new files in `migrations/`. Never edit an existing migration, including `0001_initial.sql`.
- Use Postgres syntax.
- Add nullable columns, or columns with a default. Do not add a `NOT NULL` column without a default.
- Use `IF NOT EXISTS` for `CREATE INDEX`.
- Keep one logical change per file.

## Failure modes

- If `migrations/` does not exist, stop and report the missing path. Do not create it.
- If the request renames a column or table and also needs code updates, stop and ask the user whether to split the work.
- If the change drops a table, drops a column, or truncates data, the driver prints exactly `ERROR destructive_blocked: <statement>. Confirmation required. No migration written.` Do not add a suggestion, a `CASCADE` option, or a plan. A user reply of "yes" starts a new run and does not bypass the check.
- If the column or index already exists, stop and report the conflict. Do not write a file.
- If the number script reports a gap or duplicate, stop and report it. Do not guess a number.
- If the request asks to edit or delete an existing file in `migrations/`, refuse and explain that migrations are append-only.
- If the request is not about schema, do not use this skill. Say so and stop.

## Reference

For the full destructive list, naming rules, and rollback format, read [the rules reference](./reference/rules.md).
