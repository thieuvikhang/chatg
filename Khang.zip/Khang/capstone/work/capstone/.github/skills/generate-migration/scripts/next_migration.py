"""Print the next migration number for a migrations/ folder. Read-only and idempotent.

Reused from Module 3 (migration-scaffold/scripts/next_migration.py).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

PATTERN = re.compile(r"^(\d{4})_.+\.sql$")


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: next_migration.py <migrations_dir>", file=sys.stderr)
        return 2
    folder = Path(argv[1])
    if not folder.is_dir():
        print(f"error: migrations folder not found: {folder}", file=sys.stderr)
        return 1

    numbers = []
    for path in folder.iterdir():
        match = PATTERN.match(path.name)
        if match:
            numbers.append(int(match.group(1)))

    if not numbers:
        print("error: no numbered migrations found", file=sys.stderr)
        return 1

    numbers.sort()
    if numbers != list(range(1, len(numbers) + 1)):
        print(f"error: gap or duplicate in migration numbers: {numbers}", file=sys.stderr)
        return 1

    print(f"{numbers[-1] + 1:04d}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
