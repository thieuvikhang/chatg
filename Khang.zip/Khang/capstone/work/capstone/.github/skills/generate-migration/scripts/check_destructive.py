"""Flag destructive SQL statements. Reads SQL from a file; exits 1 if any match. Read-only.

Reused from Module 3 (migration-scaffold/scripts/check_destructive.py).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

DESTRUCTIVE = re.compile(
    r"\b(DROP\s+TABLE|DROP\s+COLUMN|DROP\s+SCHEMA|TRUNCATE|DELETE\s+FROM)\b",
    re.IGNORECASE,
)


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: check_destructive.py <sql_file>", file=sys.stderr)
        return 2
    sql = Path(argv[1]).read_text(encoding="utf-8")

    hits = [line.strip() for line in sql.splitlines() if DESTRUCTIVE.search(line)]
    if not hits:
        print("OK: no destructive statements")
        return 0

    print("DESTRUCTIVE: confirmation required")
    for hit in hits:
        print(f"  {hit}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
