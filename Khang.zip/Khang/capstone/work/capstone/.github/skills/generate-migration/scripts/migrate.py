"""Generate one append-only migration with a rollback block. Driver for the generate-migration skill.

Order: validate spec -> destructive gate -> next number -> schema check -> render
-> rollback check -> verifier verdict (--verdict file) -> write.
Nothing is written unless every check passes.

Usage:
  python migrate.py <spec.json> <migrations_dir> [--verdict <verdict.json>]

Without --verdict the write is blocked: the migration-verifier agent must run first
and its JSON verdict must be passed in.

Exit codes: 0 written, 1 invalid request or schema conflict, 2 usage,
3 rollback or verifier rejected, 4 destructive change blocked.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
SCRIPTS = SKILL / "scripts"
TEMPLATE = SKILL / "templates" / "migration.sql.tpl"

sys.path.insert(0, str(SCRIPTS))
from check_destructive import DESTRUCTIVE  # noqa: E402

IDENT = re.compile(r"^[a-z][a-z0-9_]{0,62}$")
TYPE = re.compile(r"^(TEXT|INTEGER|BIGINT|BOOLEAN|TIMESTAMPTZ|JSONB|VARCHAR\(\d+\)|NUMERIC\(\d+,\s*\d+\))$")
DEFAULT = re.compile(r"^(now\(\)|'[^';]*'|-?\d+(\.\d+)?|true|false|null)$")
OPERATIONS = {"add_column", "create_index", "drop_column", "drop_table", "truncate"}
ADD_COLUMN = re.compile(r"^ALTER TABLE (\w+) ADD COLUMN (\w+)")
CREATE_INDEX = re.compile(r"^CREATE INDEX IF NOT EXISTS (\w+) ON")


def validate_spec(spec: object) -> list[str]:
    if not isinstance(spec, dict):
        return ["spec must be a JSON object"]
    errors = []
    op = spec.get("operation")
    if op not in OPERATIONS:
        errors.append(f"unknown operation: {op}")
    if not IDENT.match(str(spec.get("table", ""))):
        errors.append(f"bad table name: {spec.get('table')}")
    if op == "add_column":
        if not IDENT.match(str(spec.get("column", ""))):
            errors.append(f"bad column name: {spec.get('column')}")
        if not TYPE.match(str(spec.get("type", ""))):
            errors.append(f"type not allowed: {spec.get('type')}")
        default = spec.get("default")
        if default is not None and not DEFAULT.match(str(default)):
            errors.append(f"default not allowed: {default}")
        if not spec.get("nullable", True) and default is None:
            errors.append("NOT NULL column needs a default")
    if op == "create_index":
        if not IDENT.match(str(spec.get("index_name", ""))):
            errors.append(f"bad index name: {spec.get('index_name')}")
        columns = spec.get("columns") or []
        if not columns or not all(IDENT.match(str(c)) for c in columns):
            errors.append("create_index needs one or more valid column names")
    if op == "drop_column" and not IDENT.match(str(spec.get("column", ""))):
        errors.append(f"bad column name: {spec.get('column')}")
    return errors


def build(spec: dict) -> tuple[str, list[str], list[str]]:
    """Return (file name part, forward statements, rollback statements)."""
    op, t = spec["operation"], spec["table"]
    if op == "add_column":
        c = spec["column"]
        null = "" if spec.get("nullable", True) else " NOT NULL"
        default = "" if spec.get("default") is None else f" DEFAULT {spec['default']}"
        return (f"add_{t}_{c}",
                [f"ALTER TABLE {t} ADD COLUMN {c} {spec['type']}{null}{default};"],
                [f"ALTER TABLE {t} DROP COLUMN {c};"])
    if op == "create_index":
        idx = spec["index_name"]
        cols = ", ".join(spec["columns"])
        return (f"create_{idx}",
                [f"CREATE INDEX IF NOT EXISTS {idx} ON {t} ({cols});"],
                [f"DROP INDEX IF EXISTS {idx};"])
    if op == "drop_column":
        c = spec["column"]
        return f"drop_{t}_{c}", [f"ALTER TABLE {t} DROP COLUMN {c};"], []
    if op == "drop_table":
        return f"drop_{t}", [f"DROP TABLE {t};"], []
    return f"truncate_{t}", [f"TRUNCATE {t};"], []


def render(number: str, name: str, description: str, fwd: list[str], back: list[str]) -> str:
    rollback = "\n".join(f"-- {s}" for s in back) or "-- (none: no automatic rollback for this change)"
    return (TEMPLATE.read_text(encoding="utf-8")
            .replace("{NUMBER}", number)
            .replace("{NAME}", name)
            .replace("{DESCRIPTION}", description or name)
            .replace("{STATEMENTS}", "\n".join(fwd))
            .replace("{ROLLBACK}", rollback))


def rollback_block(rendered: str) -> list[str]:
    inside, out = False, []
    for line in rendered.splitlines():
        if line.startswith("-- ROLLBACK BEGIN"):
            inside = True
        elif line.startswith("-- ROLLBACK END"):
            break
        elif inside and line.startswith("-- ") and line.endswith(";"):
            out.append(line[3:])
    return out


def rollback_check(fwd: list[str], rendered: str) -> str | None:
    """Return an error message if the rendered rollback does not invert the forward statements."""
    back = rollback_block(rendered)
    for stmt in fwd:
        if m := ADD_COLUMN.match(stmt):
            want = f"ALTER TABLE {m.group(1)} DROP COLUMN {m.group(2)};"
        elif m := CREATE_INDEX.match(stmt):
            want = f"DROP INDEX IF EXISTS {m.group(1)};"
        else:
            return f"no rollback rule for statement: {stmt}"
        if want not in back:
            return f"rollback missing: {want}"
    return None


def run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, *cmd], capture_output=True, text=True)


def main(argv: list[str]) -> int:
    args = argv[1:]
    verdict_path = None
    if "--verdict" in args:
        i = args.index("--verdict")
        if i + 1 >= len(args):
            print("usage: migrate.py <spec.json> <migrations_dir> [--verdict <verdict.json>]", file=sys.stderr)
            return 2
        verdict_path = Path(args[i + 1])
        del args[i:i + 2]
    if len(args) != 2:
        print("usage: migrate.py <spec.json> <migrations_dir> [--verdict <verdict.json>]", file=sys.stderr)
        return 2
    spec_path, migrations = Path(args[0]), Path(args[1])

    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as err:
        print(f"ERROR invalid_spec: {err}")
        return 1
    errors = validate_spec(spec)
    if errors:
        print("ERROR invalid_spec: " + "; ".join(errors))
        return 1

    name, fwd, back = build(spec)
    for stmt in fwd:
        if DESTRUCTIVE.search(stmt):
            print(f"ERROR destructive_blocked: {stmt}. Confirmation required. No migration written.")
            return 4

    if not migrations.is_dir():
        print(f"ERROR missing_migrations_dir: {migrations}")
        return 1
    num = run([str(SCRIPTS / "next_migration.py"), str(migrations)])
    if num.returncode != 0:
        print(f"ERROR numbering: {num.stderr.strip()}")
        return 1
    number = num.stdout.strip()

    check = run([str(SCRIPTS / "validate_request.py"), str(migrations), str(spec_path)])
    if check.returncode != 0:
        print(check.stdout.strip())
        return 1

    rendered = render(number, name, spec.get("description", ""), fwd, back)
    if err := rollback_check(fwd, rendered):
        print(f"ERROR rollback_invalid: {err}")
        return 3

    if verdict_path is None:
        print("ERROR verifier_missing: run the migration-verifier agent and pass --verdict. No migration written.")
        return 3
    try:
        verdict = json.loads(verdict_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as err:
        print(f"ERROR verifier_invalid: {err}")
        return 3
    if verdict.get("verdict") != "approved" or verdict.get("reversible") is not True:
        print("ERROR verifier_rejected: " + " | ".join(verdict.get("issues", []) + [verdict.get("reasoning", "")]))
        return 3

    target = migrations / f"{number}_{name}.sql"
    if target.exists():
        print(f"ERROR file_exists: {target}")
        return 1
    target.write_text(rendered, encoding="utf-8")
    print(f"WROTE {target}")
    for stmt in fwd:
        print(f"  {stmt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
