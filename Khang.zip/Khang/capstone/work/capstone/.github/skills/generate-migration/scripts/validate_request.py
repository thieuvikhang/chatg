"""Check a migration spec against the schema rebuilt from migrations/. Read-only.

Exit 0 if the change can be applied, 1 if the table is missing or the column or
index already exists.

Usage: validate_request.py <migrations_dir> <spec.json>
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

FILE = re.compile(r"^\d{4}_.+\.sql$")
CREATE_TABLE = re.compile(r"^CREATE TABLE (?:IF NOT EXISTS )?(\w+) \((.*)\)$", re.I)
ADD_COLUMN = re.compile(r"^ALTER TABLE (\w+) ADD COLUMN (?:IF NOT EXISTS )?(\w+)", re.I)
RENAME_COLUMN = re.compile(r"^ALTER TABLE (\w+) RENAME COLUMN (\w+) TO (\w+)", re.I)
DROP_COLUMN = re.compile(r"^ALTER TABLE (\w+) DROP COLUMN (?:IF EXISTS )?(\w+)", re.I)
CREATE_INDEX = re.compile(r"^CREATE (?:UNIQUE )?INDEX (?:CONCURRENTLY )?(?:IF NOT EXISTS )?(\w+) ON", re.I)
DROP_TABLE = re.compile(r"^DROP TABLE (?:IF EXISTS )?(\w+)", re.I)
TABLE_KEYWORDS = {"PRIMARY", "UNIQUE", "CONSTRAINT", "CHECK", "FOREIGN"}


def strip_comments(sql: str) -> str:
    return "\n".join(line for line in sql.splitlines() if not line.strip().startswith("--"))


def split_top(body: str) -> list[str]:
    """Split on commas that are not inside parentheses."""
    parts, depth, cur = [], 0, ""
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    parts.append(cur)
    return [p.strip() for p in parts if p.strip()]


def rebuild(folder: Path) -> tuple[dict[str, set[str]], set[str]]:
    tables: dict[str, set[str]] = {}
    indexes: set[str] = set()
    for path in sorted(p for p in folder.iterdir() if FILE.match(p.name)):
        for stmt in strip_comments(path.read_text(encoding="utf-8-sig")).split(";"):
            s = " ".join(stmt.split())
            if not s:
                continue
            if m := CREATE_TABLE.match(s):
                cols = {c.split()[0].lower() for c in split_top(m.group(2))
                        if c.split()[0].upper() not in TABLE_KEYWORDS}
                tables[m.group(1).lower()] = cols
            elif m := ADD_COLUMN.match(s):
                tables.setdefault(m.group(1).lower(), set()).add(m.group(2).lower())
            elif m := RENAME_COLUMN.match(s):
                cols = tables.get(m.group(1).lower(), set())
                cols.discard(m.group(2).lower())
                cols.add(m.group(3).lower())
            elif m := DROP_COLUMN.match(s):
                tables.get(m.group(1).lower(), set()).discard(m.group(2).lower())
            elif m := CREATE_INDEX.match(s):
                indexes.add(m.group(1).lower())
            elif m := DROP_TABLE.match(s):
                tables.pop(m.group(1).lower(), None)
    return tables, indexes


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("usage: validate_request.py <migrations_dir> <spec.json>", file=sys.stderr)
        return 2
    folder = Path(argv[1])
    spec = json.loads(Path(argv[2]).read_text(encoding="utf-8-sig"))
    if not folder.is_dir():
        print(f"ERROR missing_migrations_dir: {folder}")
        return 1

    tables, indexes = rebuild(folder)
    op = spec.get("operation")
    table = spec.get("table", "")
    errors = []
    if table not in tables:
        errors.append(f"table not found: {table}")
    elif op == "add_column" and spec.get("column") in tables[table]:
        errors.append(f"column already exists: {table}.{spec.get('column')}")
    elif op == "create_index":
        if spec.get("index_name") in indexes:
            errors.append(f"index already exists: {spec.get('index_name')}")
        for col in spec.get("columns", []):
            if col not in tables[table]:
                errors.append(f"column not found: {table}.{col}")

    if errors:
        print("ERROR schema_conflict: " + "; ".join(errors))
        return 1
    print("OK: schema check passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
