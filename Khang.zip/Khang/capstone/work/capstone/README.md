# Capstone: Auto-generate a migration with rollback

Task A from the capstone brief. Ask Copilot to add, drop, or index a column or table, and it writes one new append-only migration file `migrations/000N_<name>.sql` with a rollback block. Destructive changes are blocked, schema conflicts are rejected, and a verifier agent must approve reversibility before the file is written.

Target repo: `labs/module-1-2/work/repo` (payments-api, Postgres 15).

## Where the files live

All workflow files are in this folder. Copilot reads them from `.github/` inside the folder opened in VS Code.

| Part | Path |
|---|---|
| Context file | [AGENTS.md](AGENTS.md) |
| Skill (SKILL.md, scripts, template, reference) | [.github/skills/generate-migration/SKILL.md](.github/skills/generate-migration/SKILL.md) |
| Subagent (appears in the Copilot agent picker) | [.github/agents/migration-verifier.agent.md](.github/agents/migration-verifier.agent.md) |
| Driver | [.github/skills/generate-migration/scripts/migrate.py](.github/skills/generate-migration/scripts/migrate.py) |
| Parse prompt | [.github/skills/generate-migration/reference/parse-request.md](.github/skills/generate-migration/reference/parse-request.md) |
| Eval golden | [goldens/add_notes_column.yaml](goldens/add_notes_column.yaml) |
| Demo specs and baseline | [demo/specs/](demo/specs/), [demo/migrations/](demo/migrations/) |

Reused from earlier modules: Module 1-2 context file, prompt library and eval harness; Module 3 `migration-scaffold` scripts and template; Module 4 verifier pattern.

## Flow

1. The parse prompt turns the request into `spec.json`.
2. The skill runs `migrate.py spec.json <target>/migrations`. This runs spec validation, the destructive gate, the next number, the schema conflict check, and the rollback check. It writes nothing yet.
3. The `migration-verifier` agent reviews the rendered migration and returns JSON. The skill saves it as `verdict.json`.
4. The skill runs `migrate.py spec.json <target>/migrations --verdict verdict.json`. The file is written only if the verdict is `approved` and `reversible` is true.

Exit codes: 0 written, 1 invalid request or conflict, 3 rollback or verifier rejected or missing, 4 destructive change blocked.

## Install

1. Open `d:\agentic-development-material-dist\capstone\work\capstone` in VS Code with GitHub Copilot Chat.
2. Confirm the agent is listed in the Chat agent picker as `migration-verifier`. Ask for a migration in a new chat and the `generate-migration` skill should be used.
3. Requires Python 3.11 or later. The driver and verifier use only the standard library.

## Run

Use Copilot Chat in agent mode and ask, for example:

> Add a notes column (TEXT, nullable) to the orders table in labs/module-1-2/work/repo/migrations.

Run the checks from the terminal without Copilot, from this folder:

```
python .github/skills/generate-migration/scripts/migrate.py demo/specs/add_notes.json <target>/migrations
```

Demo cases (run against a copy of `demo/migrations`):

- `demo/specs/add_notes.json`: without a verdict, exit 3 `verifier_missing`. With an approved verdict, writes `0002_add_orders_notes.sql` with a rollback. Exit 0.
- `demo/specs/add_status_index.json`: writes an index migration with `DROP INDEX IF EXISTS` in the rollback. Exit 0 with an approved verdict.
- `demo/specs/drop_legacy_flag.json`: blocked with `ERROR destructive_blocked`. Exit 4, no file written.

Running `add_notes.json` again against the same folder prints `ERROR schema_conflict: column already exists: orders.notes` and exits 1.

Eval the prompt against its golden case:

```
python harness/run_eval.py --strict
```

## Live demo order

1. Show the eval passing.
2. Ask Copilot for the notes column. Show the verifier agent run and the rendered file with its rollback block.
3. Ask for dropping `legacy_flag`. Show the block.
4. Ask for the notes column again. Show the conflict.

## Known limits

- The schema check is a regex parser over the migration files. It covers `CREATE TABLE`, `ADD COLUMN`, `RENAME COLUMN`, `DROP COLUMN`, `CREATE INDEX`, and `DROP TABLE`. It does not parse every Postgres form.
- The rollback check is string-based. It confirms the rollback block contains the inverse of each forward statement but does not run SQL against a database.
- The verifier is an LLM check and can be wrong. The driver only trusts an approved verdict that matches the schema; it does not replace it.
- The eval harness uses a fixture shim, so it checks the parse prompt's contract against a recorded output, not a live model call.

## Reflection

If I had another capstone session, I would have the driver run the generated SQL against a throwaway Postgres container in CI, so rollback is tested by execution and not by string match. I would also add a second verifier that checks application code for references to a column before a rename or drop is allowed, since the current skill only checks the schema.
