This change renames a column and also updates code references, so the skill requires confirmation before writing anything. I'll ask how to split it.

Analyzing your answers...

You chose the migration only. The `0002` number is now taken by the notes migration, so I'll get the next number first.

Ran terminal command: python migration-scaffold\scripts\next_migration.py migrations

Next number is `0003`. Running the destructive check on the rename statement.

Ran terminal command: Set-Content -Path "$env:TEMP\candidate_0003.sql" -Value "ALTER TABLE orders RENAME COLUMN created_at TO placed_at;" -Encoding UTF8; python migration-scaffold\scripts\check_destructive.py "$env:TEMP\candidate_0003.sql"

Created 

I wrote `0003_rename_orders_created_at.sql` with the statement `ALTER TABLE orders RENAME COLUMN created_at TO placed_at;`. The destructive check passed. The migration has not been run.

I did not update code references, since that is outside this skill's scope. Any code that reads `created_at` on `orders` will need a separate change before or alongside deployment.

Made changes.