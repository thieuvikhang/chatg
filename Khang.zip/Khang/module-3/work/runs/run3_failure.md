Read 

Read skill `migration-scaffold`

Dropping a table is destructive, so I'll check the next migration number and the rules before asking for confirmation.

Read skill `migration-scaffold`: 

Ran terminal command: python scripts/next_migration.py migrations

The script path was wrong. Retrying with the full path.

Ran terminal command: python .github\skills\migration-scaffold\scripts\next_migration.py migrations

Read skill `migration-scaffold`: 

Searched for text `users` (`**/migrations/**`), 3 results

Read 

Dropping `users` is destructive, so I have not written a file yet.

Proposed migration: `migrations/0004_drop_users_table.sql` with:

```sql
DROP TABLE users;
```

Before you confirm, note these issues:

- `orders.user_id` has a foreign key to `users(id)` in `0001_initial.sql:20`. Plain `DROP TABLE users` will fail while `orders` references it. Using `DROP TABLE users CASCADE` would remove that foreign key from `orders`, and the `ix_users_email` index is dropped along with the table.
- Every row in `users` is lost, and the rows in `orders` would no longer link to a user.

Should I write the migration as `DROP TABLE users;` or `DROP TABLE users CASCADE;`? Or do you want a different plan, such as dropping the `orders.user_id` foreign key first?