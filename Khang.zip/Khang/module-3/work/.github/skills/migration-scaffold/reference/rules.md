# Migration rules

## Naming

- File: `migrations/000N_<snake_name>.sql`. `N` is the next number, zero-padded to 4 digits.
- `<snake_name>` describes the change, for example `add_orders_notes` or `create_order_index`.
- Numbers are ascending with no gaps. The number script checks this.

## Destructive operations (require explicit confirmation)

- `DROP TABLE`
- `DROP COLUMN`
- `DROP SCHEMA`
- `TRUNCATE`
- `DELETE FROM` (data changes belong in a separate, reviewed data migration)

When one of these appears, show the statement and ask the user to confirm the object name before writing the file.

## Safe defaults

- New columns: nullable, or `NOT NULL` with a `DEFAULT`.
- Indexes: `CREATE INDEX IF NOT EXISTS`.
- Foreign keys: name the constraint explicitly.

## Out of scope for this skill

- Editing or deleting an existing migration.
- Running migrations. Deployment applies them.
- Application code that uses the new schema.
