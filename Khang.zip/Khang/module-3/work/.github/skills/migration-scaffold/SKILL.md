---
name: migration-scaffold
version: 0.1.0
description: 'Scaffold a new append-only SQL migration file in migrations/ with the next sequence number. Use when the user asks to add a migration, add a column or table, drop a column or table, add an index, or change schema, including phrases like "add a migration", "add a notes column to orders", "create a migration for", "drop the users table", "add an index on". Stops for confirmation on destructive changes. Do NOT use for editing existing migration files, running migrations, application code changes, or SELECT queries.'
---

# Migration Scaffold

Creates one new `migrations/000N_<snake_name>.sql` file per schema change. Migrations are append-only.

Use this skill when a schema change must be recorded as a new migration file. It does not apply migrations and does not change application code.

## Steps

1. Run [next number script](./scripts/next_migration.py) with the migrations folder path, for example `python scripts/next_migration.py migrations`. It prints the next number (for example `0002`). If it exits non-zero, stop and report the error.
2. Take the requested change and turn it into SQL statements. If the change needs more than one operation, or if it also needs application code edits, ask the user to confirm scope before continuing.
3. Save the SQL statements to a temporary file and run [destructive check](./scripts/check_destructive.py) on it. If it reports a match, stop, show the matched statement, and ask for explicit confirmation. Do not write the migration file.
4. Fill [the migration template](./templates/migration.sql.tpl) with `{NUMBER}`, `{NAME}`, `{DESCRIPTION}`, and `{STATEMENTS}`.
5. Write the file to `migrations/{NUMBER}_{NAME}.sql`. Use snake_case for `{NAME}`.
6. Report the file path and the statements written. Do not run the migration.

## Example

Request: "Add a migration that adds a notes column (TEXT, nullable) to the orders table."

- Number script prints `0002`.
- Statement: `ALTER TABLE orders ADD COLUMN notes TEXT;`
- Destructive check passes.
- Writes `migrations/0002_add_orders_notes.sql` from the template.
- Reports the path and the single statement.

## Conventions

- Only create new files in `migrations/`. Never edit an existing migration, including `0001_initial.sql`.
- Use Postgres syntax. The schema uses `JSONB` and `TIMESTAMPTZ`.
- Add nullable columns or columns with a default. Do not add a `NOT NULL` column without a default to a table that may have rows.
- Use `IF NOT EXISTS` for `CREATE INDEX` and `CREATE TABLE`.
- Keep one logical change per file.

## Failure modes

- If `migrations/` does not exist, stop and report the missing path. Do not create it.
- If the requested change renames a column or table and also needs code updates, stop and ask the user whether to split the work. Do not update application code from this skill.
- If the change drops a table, drops a column, or truncates data, stop and surface a warning naming the object. Do not write any file until the user confirms.
- If the number script reports a gap or duplicate number, stop and report it. Do not guess a number.
- If the request asks to edit or delete an existing file in `migrations/`, refuse and explain that migrations are append-only.
- If the request is not about schema (for example, a code refactor or a query), do not use this skill. Say so and stop.

## Reference

For the full destructive-operation list and naming rules, read [the rules reference](./reference/rules.md).
