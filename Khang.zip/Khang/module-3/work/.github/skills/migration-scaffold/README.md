# migration-scaffold

Task family: **migration-scaffold**. Creates a new numbered, append-only SQL migration file in `migrations/` for a schema change.

## Who uses it

Developers on the payments-api team who need a schema change recorded as a migration, with the next number chosen correctly and destructive changes stopped for confirmation.

## What it does

- Picks the next migration number (`scripts/next_migration.py`). Fails on gaps or a missing folder.
- Flags destructive SQL: `DROP`, `TRUNCATE`, `DELETE FROM` (`scripts/check_destructive.py`).
- Writes `migrations/000N_<name>.sql` from `templates/migration.sql.tpl`.
- Does not apply migrations, edit existing migrations, or change application code.

## Install (Copilot)

Copy this folder to `.github/skills/migration-scaffold/` in the workspace, then start a new Copilot Chat session and confirm the skill appears when you ask for a migration.

## Layout

```
SKILL.md                      # contract: when to use, steps, failure modes
scripts/next_migration.py
scripts/check_destructive.py
templates/migration.sql.tpl
reference/rules.md            # naming, destructive list, safe defaults
```
