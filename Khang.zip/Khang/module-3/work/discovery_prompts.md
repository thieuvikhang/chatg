# Discovery contract test prompts — migration-scaffold

Run each prompt in a fresh Copilot Chat session with the skill installed at `.github/skills/migration-scaffold/`. Record whether the skill loads (look for it in the tool/skill trace).

## Positive prompts (should trigger)

1. "Add a migration that adds a notes column to the orders table."
2. "Create a migration for a new shipments table."
3. "Add an index on orders.status."
4. "Drop the legacy_flag column from users."
5. "I need a migration to add a nullable promo_code column to orders."

## Negative prompts (should stay silent)

1. "Edit migrations/0001_initial.sql to add a comment."
2. "Run the pending migrations against staging."
3. "Write a SELECT that counts orders per user."
4. "Refactor app/orders/routes.py to use a service class."
5. "Explain what the orders table is for."

## Results

Not yet run. See the note in the report about this environment.
